﻿using Abp.Zero.EntityFrameworkCore;
using ToeicReadingApp.Authorization.Roles;
using ToeicReadingApp.Authorization.Users;
using ToeicReadingApp.MultiTenancy;
using Microsoft.EntityFrameworkCore;

namespace ToeicReadingApp.EntityFrameworkCore;

public class ToeicReadingAppDbContext : AbpZeroDbContext<Tenant, Role, User, ToeicReadingAppDbContext>
{
    /* Define a DbSet for each entity of the application */

    public ToeicReadingAppDbContext(DbContextOptions<ToeicReadingAppDbContext> options)
        : base(options)
    {
    }
}
